# Overview
This is Project 2 of NYU-cs6903.
Team members: Scott Cohen, Zhendong Tan, David Zhao, Bhavish Yalamanchi
Title: Homomorphic Arithmetic Operations on Ciphertexts
Group name: Really Special Amigos (RSA)

Project type3:
https://brightspace.nyu.edu/content/enforced/176739-945-1224_SP22CS-GYCS-UY47836903AIINET/Project%20type%203.pdf?_&d2lSessionVal=v2g9dg6En8YZjUeyamDMneVB6&_&d2lSessionVal=jPqtZPmzw1HmtcvbC9tGEDuJL&_&d2lSessionVal=0DCAP3vUzXnF9ekIXErtj7phb&_&d2lSessionVal=UWGLpEyW63eegmIehkaiUKyXp&_&d2lSessionVal=Yzj8rd63uBI3qpD6zj9m3n2B9

# Report/Presentation
https://docs.google.com/presentation/d/1n56LFGKkzyGzMJ9SUUcd2fqMiR0Po7hrVboLTvCzuuk/edit?usp=sharing

# Reference
https://github.com/AndrewQuijano/Homomorphic_Encryption
https://github.com/AndrewQuijano/Homomorphic_Encryption/blob/master/Homomorphic_Encryption_Library_Performance.pdf
