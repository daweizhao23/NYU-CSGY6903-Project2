package security.DGK;

import java.math.BigInteger;

public interface DGK_Key 
{
	public BigInteger getU();
	public BigInteger getN();
	public int getL();
}
