package security.gm;

import java.math.BigInteger;

public interface GMKey 
{
	public BigInteger getN();
}
