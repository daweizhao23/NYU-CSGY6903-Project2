package security.elgamal;

import java.math.BigInteger;

public interface ElGamal_Key 
{
	public BigInteger getP();
}
