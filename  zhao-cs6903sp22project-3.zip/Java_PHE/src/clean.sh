#!/bin/bash

rm -rf ./security/elgamal/*.class
rm -rf ./security/DGK/*.class
rm -rf ./security/paillier/*.class
rm -rf ./security/generic/*.class
rm -rf ./security/socialistmillionaire/*.class
rm -rf ./Main.class
rm -rf ./bin/clean.sh
